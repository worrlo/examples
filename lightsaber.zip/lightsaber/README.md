# CSS Only Lightsaber
A clone of the workup found in the "CSS Only Lightsaber" Youtube video by @kevin-powell

https://youtu.be/CBw9-K6hYVA